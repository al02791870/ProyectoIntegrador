
package config;

import java.sql.Connection;
import java.sql.DriverManager;

public class Conexion2 {
    Connection con;
    String url="jdbc:mysql://localhost:3306/calificaciones";
    String user="root";
    String pass="admin";
    public Connection Conexion(){
        try {
            Class.forName("com.mysql.jdbc.Driver");
            con=DriverManager.getConnection(url,user,pass);
        } catch (Exception e) {
        	System.out.println("hubo un error al conectarse");
        	System.out.println(e);
        }
        return con;
    }
}















