package modelo;

public class Alumno {
    int id;
    String dni;
    int grado;
    int calEsp;
    int calMat;
    int calCN;
    int calGeo;
    int calHis;
    int calFCyE;
    int calArt;
    int prom;
    
    public Alumno(int id, String dni, int grado, int calEsp, int calMat, int calCN, int calGeo, int calHis, int calFCyE, int calArt, int prom) {
        this.id = id;
        this.dni = dni;
        this.grado = grado;
        this.calEsp = calEsp;
        this.calMat = calMat;
        this.calCN = calCN;
        this.calGeo = calGeo;
        this.calHis = calHis;
        this.calFCyE = calFCyE;
        this.calArt = calArt;
        this.prom = prom;
        
    }
    public int getGrado() {
		return grado;
	}
	public void setGrado(int grado) {
		this.grado = grado;
	}
	public int getCalEsp() {
		return calEsp;
	}
	public void setCalEsp(int calEsp) {
		this.calEsp = calEsp;
	}
	public int getCalMat() {
		return calMat;
	}
	public void setCalMat(int calMat) {
		this.calMat = calMat;
	}
	public int getCalCN() {
		return calCN;
	}

	public void setCalCN(int calCN) {
		this.calCN = calCN;
	}

	public int getCalGeo() {
		return calGeo;
	}

	public void setCalGeo(int calGeo) {
		this.calGeo = calGeo;
	}

	public int getCalHis() {
		return calHis;
	}

	public void setCalHis(int calHis) {
		this.calHis = calHis;
	}

	public int getCalFCyE() {
		return calFCyE;
	}

	public void setCalFCyE(int calFCyE) {
		this.calFCyE = calFCyE;
	}

	public int getCalArt() {
		return calArt;
	}

	public void setCalArt(int calArt) {
		this.calArt = calArt;
	}

	public int getProm() {
		return prom;
	}

	public void setProm(int prom) {
		this.prom = prom;
	}

	public Alumno() {
    }

    

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getDni() {
        return dni;
    }

    public void setDni(String dni) {
        this.dni = dni;
    }


   

   
    
    
}
