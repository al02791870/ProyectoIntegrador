
package modelo;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import config.Conexion2;

public class AlumnoDAO {
    Conexion2 cn = new Conexion2();
    Connection con;
    PreparedStatement ps;
    ResultSet rs;
    int r;
    
    public Alumno buscar(String dni){
        Alumno c=new Alumno();
        String sql="Select * from alumnos where Dni="+dni;
        try {
            con=cn.Conexion();
            ps=con.prepareStatement(sql);
            rs=ps.executeQuery();
            while (rs.next()) {
                c.setId(rs.getInt(1));
                c.setDni(rs.getString(2));
                c.setGrado(rs.getInt(3));
                c.setCalEsp(rs.getInt(4));                
                c.setCalMat(rs.getInt(5));                
            }
        } catch (Exception e) {
        }
        return c;
    }

//*******Operaciones CRUD***************//
    public List listar(){
        String sql="select * from alumnos";
        List<Alumno>lista=new ArrayList<>();
        
        try {
            con=cn.Conexion();
            ps=con.prepareStatement(sql);
            rs=ps.executeQuery();
            while (rs.next()) {
                Alumno cl=new Alumno();
                cl.setId(rs.getInt(1));
                cl.setDni(rs.getString(2));
                cl.setGrado(rs.getInt(3));
                cl.setCalEsp(rs.getInt(4));
                cl.setCalMat(rs.getInt(5));  
                cl.setCalCN(rs.getInt(6)); 
                cl.setCalGeo(rs.getInt(7));
                cl.setCalHis(rs.getInt(8));
                cl.setCalFCyE(rs.getInt(9));
                cl.setCalArt(rs.getInt(10));
                cl.setProm(rs.getInt(11));
                lista.add(cl);
                
            }
        } catch (Exception e) {
        }
        return lista;
    }
    public int agregar(Alumno cl){ 
        String sql="insert into alumnos(Dni, Nombre, Grado,CalEsp)values(?,?,?,?)";
        try {
            con=cn.Conexion();
            ps=con.prepareStatement(sql);
            ps.setString(1, cl.getDni());
            ps.setInt(2, cl.getGrado());
            ps.setInt(3, cl.getCalEsp());
            ps.setInt(4, cl.getCalMat());           
            ps.executeUpdate();
        } catch (Exception e) {
        }
        return r;
        
    }
    public Alumno listarId(int id){
        Alumno cli=new Alumno();
        String sql="select * from alumnos where Idalumnos="+id;
        try {
            con=cn.Conexion();
            ps=con.prepareStatement(sql);
            rs=ps.executeQuery();
            while (rs.next()) {
                cli.setDni(rs.getString(2));
                cli.setGrado(rs.getInt(3));
                cli.setCalEsp(rs.getInt(4));
                cli.setCalMat(rs.getInt(5));              
            }
        } catch (Exception e) {
        }
        return cli;
    }
    public int actualizar(Alumno em){
        String sql="update alumnos set Dni=?, Nombre=?, Grado=?,CalEsp=? where Idalumnos=?";
        try {
            con=cn.Conexion();
            ps=con.prepareStatement(sql);
            ps.setString(1, em.getDni());
            ps.setInt(2, em.getGrado());
            ps.setInt(3, em.getCalEsp());
            ps.setInt(4, em.getCalMat());           
            ps.setInt(5, em.getId());
            ps.executeUpdate();
        } catch (Exception e) {
        }
        return r;
    }
    public void delete(int id){
        String sql="delete from alumnos where Idalumnos="+id;
        try {
            con=cn.Conexion();
            ps=con.prepareStatement(sql);
            ps.executeUpdate();
        } catch (Exception e) {
        }
    }
    
}
